<?php
/*
Plugin Name: Custom Template Footer
Plugin URI: https://github.com/nxvermore
Description: This plugin allows you to add a custom template part as the footer of WordPress entries.
Version: 1.0
Author: Nxvermore
Author URI: https://github.com/nxvermore
*/

// Add a meta box to the post editor screen
add_action( 'add_meta_boxes', 'ctf_add_custom_template_metabox' );

function ctf_add_custom_template_metabox() {
    add_meta_box(
        'ctf_custom_template',
        'Custom Template Footer',
        'ctf_render_custom_template_metabox',
        'post',
        'normal',
        'high'
    );
}

// Render the meta box content
function ctf_render_custom_template_metabox( $post ) {
    // Add nonce for security and authentication
    wp_nonce_field( 'ctf_save_custom_template', 'ctf_custom_template_nonce' );
    
    // Retrieve the current value of the custom template
    $custom_template = get_post_meta( $post->ID, '_ctf_custom_template', true );
    
    // Display the form
    ?>
    <label for="ctf_custom_template">Custom Template:</label><br />
    <?php
    // Get the WPBakery template list
    $templates = array();
    $vc_templates = get_posts( array(
        'post_type' => 'vc_grid_item',
        'numberposts' => -1,
        'orderby' => 'title',
        'order' => 'ASC',
    ) );
    if ( $vc_templates ) {
        foreach ( $vc_templates as $template ) {
            $templates[$template->ID] = $template->post_title;
        }
    }
    
    // Display the select box with the available WPBakery templates
    if ( ! empty( $templates ) ) {
        ?>
        <select name="ctf_custom_template" id="ctf_custom_template">
            <option value="">Select a template...</option>
            <?php foreach ( $templates as $template_id => $template_name ) : ?>
                <option value="<?php echo esc_attr( $template_id ); ?>" <?php selected( $custom_template, $template_id ); ?>><?php echo esc_html( $template_name ); ?></option>
            <?php endforeach; ?>
        </select>
        <?php
    } else {
        echo 'No WPBakery templates found.';
    }
}

// Save the meta box data
add_action( 'save_post', 'ctf_save_custom_template' );

function ctf_save_custom_template( $post_id ) {
    // Check if nonce is set
    if ( ! isset( $_POST['ctf_custom_template_nonce'] ) ) {
        return;
    }
    
    // Verify nonce
    if ( ! wp_verify_nonce( $_POST['ctf_custom_template_nonce'], 'ctf_save_custom_template' ) ) {
        return;
    }
    
    // Check if user has permissions to save data
    if ( ! current_user_can( 'edit_post', $post_id ) ) {
        return;
    }
    
    // Save the custom template value
    if ( isset( $_POST['ctf_custom_template'] ) ) {
        update_post_meta( $post_id, '_ctf_custom_template', sanitize_text_field( $_POST['ctf_custom_template'] ) );
    }
}

// Display the custom template as the footer of the entry
add_action( 'wp_footer', 'ctf_display_custom_template_footer' );

function ctf_display_custom_template_footer() {
// Get the current post ID
$post_id = get_the_ID();
// Check if the custom template is set for this post
$custom_template = get_post_meta( $post_id, '_ctf_custom_template', true );

if ( ! empty( $custom_template ) ) {
    // Render the WPBakery template
    echo do_shortcode( '[vc_row][vc_column][vc_single_image image="' . $custom_template . '"][/vc_column][/vc_row]' );
}
}

?>
